#ifndef _GOAP_ACTIONLIST_H_
#define _GOAP_ACTIONLIST_H_

// Contains all implemented actions

#include "Stab.h"
#include "TestAction.h"

#endif