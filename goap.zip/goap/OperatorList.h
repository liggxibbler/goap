#ifndef _GOAP_OPERATORLIST_H_
#define _GOAP_OPERATORLIST_H_

#include "Equal.h"
#include "GreaterThan.h"
#include "True.h"
#include "Owns.h"

#endif