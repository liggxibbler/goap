#include "StabTemplate.h"
#include "Agent.h"

using namespace GOAP;

StabTemplate::StabTemplate()
{
}